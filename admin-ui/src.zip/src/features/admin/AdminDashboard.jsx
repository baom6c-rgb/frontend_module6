// src/features/admin/AdminDashboard.jsx
import React, { useEffect, useMemo, useRef, useState } from "react";
import { Box, Typography, Fade, CircularProgress, Stack } from "@mui/material";

import axiosPrivate from "../../api/axiosPrivate";
import { adminAnalyticsApi } from "../../api/adminAnalyticsApi";

import AdminDashboardFilterBar from "./components/dashboard/AdminDashboardFilterBar";

import {
    AdminDashboardKpiCards,
    AdminDashboardTrends,
    AdminDashboardAtRiskTable,
    AdminDashboardAiInsightPanel,
    StudentQuickDrawer,
} from "./components/dashboard";

import {
    DASHBOARD_COLORS as COLORS,
    normalizeOption,
    buildRequestBody,
    getDefaultFilters7d,
} from "./components/dashboard/dashboard.helpers";

const PageShell = ({ children }) => (
    <Box sx={{ width: "100%", mx: "auto", px: { xs: 2, md: 6 }, pb: 4 }}>
        {children}
    </Box>
);

export default function AdminDashboard() {
    const initFilters = () => {
        const f = getDefaultFilters7d();
        return {
            preset: f.preset ?? "7d",
            classId: "",
            moduleId: "",
            keyword: "", // giữ để sau mở rộng, hiện tại UI filter bar không dùng search
            fromDate: f.from?.slice(0, 10),
            toDate: f.to?.slice(0, 10),
        };
    };

    const [filters, setFilters] = useState(initFilters);

    const [overview, setOverview] = useState(null);
    const [dashLoading, setDashLoading] = useState(false);
    const [dashError, setDashError] = useState("");

    const [classes, setClasses] = useState([]);
    const [modules, setModules] = useState([]);

    const [aiLoading, setAiLoading] = useState(false);
    const [aiError, setAiError] = useState("");
    const [aiInsight, setAiInsight] = useState(null);

    const [selectedStudent, setSelectedStudent] = useState(null);
    const [drawerOpen, setDrawerOpen] = useState(false);

    const atRiskSectionRef = useRef(null);

    useEffect(() => {
        bootstrap();
        // eslint-disable-next-line react-hooks/exhaustive-deps
    }, []);

    const bootstrap = async () => {
        try {
            const [clsRes, modRes] = await Promise.all([
                axiosPrivate.get("/classes"),
                axiosPrivate.get("/modules"),
            ]);

            const clsList = Array.isArray(clsRes.data) ? clsRes.data : clsRes.data?.data || [];
            const modList = Array.isArray(modRes.data) ? modRes.data : modRes.data?.data || [];

            setClasses(clsList.map(normalizeOption));
            setModules(modList.map(normalizeOption));
        } catch (e) {
            console.warn("bootstrap classes/modules failed:", e);
        } finally {
            fetchOverview(filters);
        }
    };

    const toApiFilters = (f) => {
        const from = f.fromDate ? `${f.fromDate}T00:00:00` : "";
        const to = f.toDate ? `${f.toDate}T23:59:59` : "";
        return {
            classId: f.classId,
            moduleId: f.moduleId,
            keyword: f.keyword,
            from,
            to,
        };
    };

    const fetchOverview = async (f) => {
        setDashError("");
        setDashLoading(true);
        try {
            const body = buildRequestBody(toApiFilters(f));
            const data = await adminAnalyticsApi.overview(body);
            setOverview(data);

            // filter đổi => reset AI insight để tránh hiểu nhầm dữ liệu cũ
            setAiInsight(null);
            setAiError("");
        } catch (e) {
            console.error("overview error:", e);
            setDashError("Không tải được thống kê. Kiểm tra quyền ADMIN và endpoint /admin/analytics/overview.");
        } finally {
            setDashLoading(false);
        }
    };

    const onResetAll = () => {
        const next = initFilters();
        setFilters(next);
        fetchOverview(next);
    };

    const onAutoApply = (next) => {
        // next là filters mới do FilterBar emit
        setFilters(next);
        fetchOverview(next);
    };

    const onJumpAtRisk = () => {
        atRiskSectionRef.current?.scrollIntoView?.({ behavior: "smooth", block: "start" });
    };

    const onSelectStudent = (student) => {
        setSelectedStudent(student);
        setDrawerOpen(true);
    };

    const runAiInsights = async () => {
        setAiError("");
        setAiLoading(true);
        try {
            const body = buildRequestBody(toApiFilters(filters));
            const data = await adminAnalyticsApi.aiInsights(body);
            setAiInsight(data);
        } catch (e) {
            console.error("ai-insights error:", e);
            setAiError("Không thể phân tích AI lúc này. Thử lại sau.");
        } finally {
            setAiLoading(false);
        }
    };

    const timeSeries = useMemo(() => overview?.timeSeries || [], [overview]);

    return (
        <Fade in timeout={350}>
            <Box sx={{ background: COLORS.bg, minHeight: "calc(100vh - 120px)" }}>
                <PageShell>
                    {/* ================= HERO HEADER + FILTER BAR ================= */}
                    <Box
                        sx={{
                            mb: 2,
                            p: { xs: 2, md: 2.5 },
                            borderRadius: "18px",
                            border: `1px solid ${COLORS.border}`,
                            background: `linear-gradient(135deg, ${COLORS.primaryBlue} 0%, ${COLORS.accentOrange} 100%)`,
                            boxShadow: "0px 18px 45px rgba(15, 23, 42, 0.10)",
                        }}
                    >
                        <Stack spacing={1.5}>
                            <Box>
                                <Typography sx={{ color: COLORS.white, fontWeight: 950, fontSize: { xs: 22, md: 28 } }}>
                                    Admin Dashboard
                                </Typography>
                                <Typography sx={{ mt: 0.3, color: "rgba(255,255,255,0.92)", fontWeight: 800 }}>
                                    Tổng quan hệ thống học viên
                                </Typography>
                            </Box>

                            {/* ✅ Filter bar custom: không search, nền mờ trong suốt, toggle được */}
                            <AdminDashboardFilterBar
                                classes={classes}
                                modules={modules}
                                filters={filters}
                                loading={dashLoading}
                                onChange={(next) => setFilters(next)}
                                onReset={onResetAll}
                                onAutoApply={onAutoApply}
                            />

                            {dashError ? (
                                <Typography sx={{ color: "rgba(255,255,255,0.92)", fontWeight: 800 }}>
                                    {dashError}
                                </Typography>
                            ) : null}
                        </Stack>
                    </Box>

                    <Box sx={{ mt: 2 }}>
                        {!overview && dashLoading ? (
                            <Box
                                sx={{
                                    p: 3,
                                    borderRadius: "18px",
                                    border: `1px solid ${COLORS.border}`,
                                    bgcolor: "#fff",
                                    boxShadow: "0px 18px 45px rgba(15, 23, 42, 0.06)",
                                }}
                            >
                                <Stack direction="row" spacing={1.5} alignItems="center">
                                    <CircularProgress size={18} sx={{ color: COLORS.primaryBlue }} />
                                    <Typography sx={{ color: COLORS.textSecondary, fontWeight: 800 }}>
                                        Đang tải thống kê...
                                    </Typography>
                                </Stack>
                            </Box>
                        ) : null}

                        {/* KPI */}
                        <Box sx={{ mt: 2 }}>
                            <AdminDashboardKpiCards overview={overview} onJumpAtRisk={onJumpAtRisk} />
                        </Box>

                        {/* Trends */}
                        <Box sx={{ mt: 3 }}>
                            <AdminDashboardTrends timeSeries={timeSeries} />
                        </Box>

                        {/* At-risk */}
                        <Box sx={{ mt: 3 }} ref={atRiskSectionRef}>
                            <AdminDashboardAtRiskTable
                                students={overview?.atRiskStudents || []}
                                onSelect={onSelectStudent}
                            />
                        </Box>

                        {/* AI panel */}
                        <Box sx={{ mt: 3 }}>
                            <AdminDashboardAiInsightPanel
                                overview={overview}
                                insight={aiInsight}
                                loading={aiLoading}
                                error={aiError}
                                onRun={runAiInsights}
                            />
                        </Box>
                    </Box>

                    <StudentQuickDrawer
                        open={drawerOpen}
                        onClose={() => setDrawerOpen(false)}
                        student={selectedStudent}
                    />
                </PageShell>
            </Box>
        </Fade>
    );
}
