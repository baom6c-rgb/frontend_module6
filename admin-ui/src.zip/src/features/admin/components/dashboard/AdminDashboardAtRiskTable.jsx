// src/features/admin/components/dashboard/AdminDashboardAtRiskTable.jsx
import React, { useMemo } from "react";
import {
    Paper,
    Box,
    Divider,
    Stack,
    Typography,
    Table,
    TableHead,
    TableRow,
    TableCell,
    TableBody,
    TableContainer,
    Chip,
} from "@mui/material";
import { WarningAmberRounded } from "@mui/icons-material";

import {
    DASHBOARD_COLORS as COLORS,
    safeNumber,
    fmtInt,
    mapRiskLevel,
    toneToChipStyle,
} from "./dashboard.helpers";

const CardShell = ({ children, sx }) => (
    <Paper
        elevation={0}
        sx={{
            borderRadius: "18px",
            border: `1px solid ${COLORS.border}`,
            background: COLORS.white,
            boxShadow: "0px 18px 45px rgba(15, 23, 42, 0.06)",
            overflow: "hidden",
            ...sx,
        }}
    >
        {children}
    </Paper>
);

export default function AdminDashboardAtRiskTable({ students = [], onSelect }) {
    const rows = useMemo(() => students || [], [students]);

    return (
        <CardShell>
            <Box sx={{ px: 2.75, py: 2.25 }}>
                <Stack direction="row" justifyContent="space-between" alignItems="center" spacing={2}>
                    <Box sx={{ minWidth: 0 }}>
                        <Typography sx={{ fontWeight: 950, color: COLORS.textPrimary, fontSize: 16 }}>
                            ⚠️ Học viên cần chú ý (Top 20)
                        </Typography>
                        <Typography sx={{ mt: 0.4, color: COLORS.textSecondary, fontWeight: 700, fontSize: 13 }}>
                            Ưu tiên xử lý nhóm có điểm thấp / tỉ lệ trượt cao
                        </Typography>
                    </Box>

                    <Chip
                        icon={<WarningAmberRounded sx={{ fontSize: 18, color: COLORS.amber }} />}
                        label={`${fmtInt(rows.length)} học viên`}
                        sx={{
                            borderRadius: "999px",
                            bgcolor: `${COLORS.amber}12`,
                            border: `1px solid ${COLORS.border}`,
                            fontWeight: 900,
                            color: COLORS.textPrimary,
                        }}
                    />
                </Stack>
            </Box>

            <Divider sx={{ borderColor: COLORS.border }} />

            <Box sx={{ p: 2.5 }}>
                <TableContainer>
                    <Table size="small">
                        <TableHead>
                            <TableRow>
                                <TableCell sx={{ fontWeight: 950, color: COLORS.textSecondary }}>Học viên</TableCell>
                                <TableCell sx={{ fontWeight: 950, color: COLORS.textSecondary }}>Bài làm</TableCell>
                                <TableCell sx={{ fontWeight: 950, color: COLORS.textSecondary }}>Điểm TB</TableCell>
                                <TableCell sx={{ fontWeight: 950, color: COLORS.textSecondary }}>Tỉ lệ trượt</TableCell>
                                <TableCell sx={{ fontWeight: 950, color: COLORS.textSecondary }}>Mức độ</TableCell>
                                <TableCell sx={{ fontWeight: 950, color: COLORS.textSecondary }}>Lý do</TableCell>
                                <TableCell sx={{ fontWeight: 950, color: COLORS.textSecondary }}>Gần nhất</TableCell>
                            </TableRow>
                        </TableHead>

                        <TableBody>
                            {rows.length === 0 ? (
                                <TableRow>
                                    <TableCell colSpan={7} sx={{ color: COLORS.textSecondary, fontWeight: 800 }}>
                                        Không có học viên cần chú ý theo bộ lọc hiện tại.
                                    </TableCell>
                                </TableRow>
                            ) : (
                                rows.map((u) => {
                                    const { label, tone } = mapRiskLevel(u?.riskLevel);
                                    const chip = toneToChipStyle(tone, COLORS);

                                    return (
                                        <TableRow
                                            key={u.userId}
                                            hover
                                            sx={{ cursor: "pointer" }}
                                            onClick={() => onSelect?.(u)}
                                        >
                                            <TableCell>
                                                <Stack spacing={0.2}>
                                                    <Typography sx={{ fontWeight: 950, color: COLORS.textPrimary }}>
                                                        {u.fullName || "(Chưa có tên)"}
                                                    </Typography>
                                                    <Typography sx={{ fontWeight: 700, color: COLORS.textSecondary, fontSize: 12 }}>
                                                        {u.email}
                                                    </Typography>
                                                </Stack>
                                            </TableCell>

                                            <TableCell sx={{ fontWeight: 900 }}>{fmtInt(u.attemptsCount)}</TableCell>
                                            <TableCell sx={{ fontWeight: 900 }}>{safeNumber(u.avgScore, 0).toFixed(1)}</TableCell>
                                            <TableCell sx={{ fontWeight: 900 }}>
                                                {Math.round(safeNumber(u.failRate, 0) * 100)}%
                                            </TableCell>

                                            <TableCell>
                                                <Chip
                                                    size="small"
                                                    label={`${label} • ${fmtInt(u.riskScore ?? 0)}`}
                                                    sx={{
                                                        bgcolor: chip.bg,
                                                        color: chip.c,
                                                        fontWeight: 950,
                                                        border: `1px solid ${COLORS.border}`,
                                                    }}
                                                />
                                            </TableCell>

                                            <TableCell sx={{ maxWidth: 360 }}>
                                                <Stack direction="row" spacing={0.75} sx={{ flexWrap: "wrap" }}>
                                                    {(u.reasons || []).slice(0, 3).map((r, idx) => (
                                                        <Chip
                                                            key={idx}
                                                            size="small"
                                                            label={r}
                                                            sx={{
                                                                bgcolor: COLORS.bg,
                                                                border: `1px solid ${COLORS.border}`,
                                                                fontWeight: 800,
                                                                color: COLORS.textSecondary,
                                                            }}
                                                        />
                                                    ))}
                                                    {(u.reasons || []).length > 3 ? (
                                                        <Chip
                                                            size="small"
                                                            label={`+${(u.reasons || []).length - 3}`}
                                                            sx={{
                                                                bgcolor: COLORS.white,
                                                                border: `1px solid ${COLORS.border}`,
                                                                fontWeight: 900,
                                                                color: COLORS.textSecondary,
                                                            }}
                                                        />
                                                    ) : null}
                                                </Stack>
                                            </TableCell>

                                            <TableCell sx={{ fontWeight: 800, color: COLORS.textSecondary }}>
                                                {u.lastAttemptAt || "-"}
                                            </TableCell>
                                        </TableRow>
                                    );
                                })
                            )}
                        </TableBody>
                    </Table>
                </TableContainer>
            </Box>
        </CardShell>
    );
}
