// src/features/admin/components/dashboard/StudentQuickDrawer.jsx
import React, { useMemo } from "react";
import { Drawer, Box, Typography, Stack, Chip, Divider, Button } from "@mui/material";
import { OpenInNewRounded, CloseRounded } from "@mui/icons-material";

import {
    DASHBOARD_COLORS as COLORS,
    safeNumber,
    mapRiskLevel,
    toneToChipStyle,
    fmtInt,
} from "./dashboard.helpers";

export default function StudentQuickDrawer({ open, onClose, student }) {
    const info = useMemo(() => {
        if (!student) return null;
        const { label, tone } = mapRiskLevel(student.riskLevel);
        return { label, tone, chip: toneToChipStyle(tone, COLORS) };
    }, [student]);

    return (
        <Drawer anchor="right" open={open} onClose={onClose}>
            <Box sx={{ width: { xs: 320, sm: 420 }, p: 2.5, bgcolor: COLORS.bg, height: "100%" }}>
                <Stack direction="row" justifyContent="space-between" alignItems="center">
                    <Typography sx={{ fontWeight: 950, color: COLORS.textPrimary, fontSize: 16 }}>
                        Chi tiết học viên
                    </Typography>
                    <Button
                        onClick={onClose}
                        startIcon={<CloseRounded />}
                        variant="outlined"
                        sx={{
                            borderRadius: "12px",
                            borderColor: COLORS.border,
                            color: COLORS.textPrimary,
                            fontWeight: 900,
                            textTransform: "none",
                            bgcolor: COLORS.white,
                        }}
                    >
                        Đóng
                    </Button>
                </Stack>

                <Divider sx={{ my: 2, borderColor: COLORS.border }} />

                {!student ? (
                    <Typography sx={{ color: COLORS.textSecondary, fontWeight: 700 }}>
                        Chọn 1 học viên để xem chi tiết.
                    </Typography>
                ) : (
                    <Stack spacing={1.25}>
                        <Box>
                            <Typography sx={{ fontWeight: 950, color: COLORS.textPrimary, fontSize: 18 }}>
                                {student.fullName || "(Chưa có tên)"}
                            </Typography>
                            <Typography sx={{ mt: 0.2, fontWeight: 700, color: COLORS.textSecondary }}>
                                {student.email}
                            </Typography>
                        </Box>

                        <Stack direction="row" spacing={1} sx={{ flexWrap: "wrap" }}>
                            <Chip
                                label={`Bài làm: ${fmtInt(student.attemptsCount)}`}
                                sx={{ bgcolor: COLORS.white, border: `1px solid ${COLORS.border}`, fontWeight: 900 }}
                            />
                            <Chip
                                label={`Điểm TB: ${safeNumber(student.avgScore, 0).toFixed(1)}`}
                                sx={{ bgcolor: COLORS.white, border: `1px solid ${COLORS.border}`, fontWeight: 900 }}
                            />
                            <Chip
                                label={`Trượt: ${Math.round(safeNumber(student.failRate, 0) * 100)}%`}
                                sx={{
                                    bgcolor: `${COLORS.danger}10`,
                                    border: `1px solid ${COLORS.border}`,
                                    color: COLORS.danger,
                                    fontWeight: 900,
                                }}
                            />
                        </Stack>

                        <Chip
                            label={`${info?.label || "N/A"} • RiskScore: ${fmtInt(student.riskScore ?? 0)}`}
                            sx={{
                                bgcolor: info?.chip.bg,
                                color: info?.chip.c,
                                border: `1px solid ${COLORS.border}`,
                                fontWeight: 950,
                            }}
                        />

                        <Box>
                            <Typography sx={{ fontWeight: 950, color: COLORS.textPrimary, mb: 0.5 }}>
                                Lý do
                            </Typography>
                            <Stack direction="row" spacing={0.75} sx={{ flexWrap: "wrap" }}>
                                {(student.reasons || []).length === 0 ? (
                                    <Typography sx={{ color: COLORS.textSecondary, fontWeight: 700 }}>
                                        Không có lý do cụ thể.
                                    </Typography>
                                ) : (
                                    (student.reasons || []).map((r, idx) => (
                                        <Chip
                                            key={idx}
                                            size="small"
                                            label={r}
                                            sx={{
                                                bgcolor: COLORS.white,
                                                border: `1px solid ${COLORS.border}`,
                                                fontWeight: 800,
                                                color: COLORS.textSecondary,
                                            }}
                                        />
                                    ))
                                )}
                            </Stack>
                        </Box>

                        <Typography sx={{ color: COLORS.textSecondary, fontWeight: 800 }}>
                            Lần làm gần nhất: {student.lastAttemptAt || "-"}
                        </Typography>

                        <Divider sx={{ borderColor: COLORS.border }} />

                        <Stack direction="row" spacing={1}>
                            <Button
                                endIcon={<OpenInNewRounded />}
                                variant="contained"
                                sx={{
                                    borderRadius: "12px",
                                    bgcolor: COLORS.primaryBlue,
                                    fontWeight: 900,
                                    textTransform: "none",
                                    boxShadow: "none",
                                    "&:hover": { bgcolor: COLORS.primaryBlueHover, boxShadow: "none" },
                                }}
                                onClick={() => {
                                    // TODO: nếu mày có route profile, tao sẽ gắn navigate chuẩn sau
                                    // ví dụ: navigate(`/admin/users/${student.userId}`)
                                    window.alert("TODO: Gắn route mở hồ sơ học viên");
                                }}
                            >
                                Mở hồ sơ
                            </Button>

                            <Button
                                variant="outlined"
                                sx={{
                                    borderRadius: "12px",
                                    borderColor: COLORS.border,
                                    color: COLORS.textPrimary,
                                    fontWeight: 900,
                                    textTransform: "none",
                                    bgcolor: COLORS.white,
                                }}
                                onClick={() => window.alert("TODO: Gắn route xem lịch sử attempt")}
                            >
                                Xem attempts
                            </Button>
                        </Stack>
                    </Stack>
                )}
            </Box>
        </Drawer>
    );
}
