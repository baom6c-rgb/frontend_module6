// src/features/admin/components/dashboard/AdminDashboardAiInsightPanel.jsx
import React from "react";
import { Paper, Box, Divider, Stack, Typography, Button, Chip, CircularProgress } from "@mui/material";
import { AutoAwesomeRounded, RefreshRounded } from "@mui/icons-material";

import { DASHBOARD_COLORS as COLORS, fmtInt } from "./dashboard.helpers";

const CardShell = ({ children, sx }) => (
    <Paper
        elevation={0}
        sx={{
            borderRadius: "18px",
            border: `1px solid ${COLORS.border}`,
            background: COLORS.white,
            boxShadow: "0px 18px 45px rgba(15, 23, 42, 0.06)",
            overflow: "hidden",
            ...sx,
        }}
    >
        {children}
    </Paper>
);

const Section = ({ title, items }) => (
    <Box>
        <Typography sx={{ fontWeight: 950, color: COLORS.textPrimary, mb: 0.75 }}>
            {title}
        </Typography>
        {(!items || items.length === 0) ? (
            <Typography sx={{ color: COLORS.textSecondary, fontWeight: 700 }}>
                Chưa có dữ liệu.
            </Typography>
        ) : (
            <Stack spacing={0.75}>
                {items.slice(0, 6).map((t, idx) => (
                    <Typography key={idx} sx={{ color: COLORS.textSecondary, fontWeight: 700 }}>
                        • {t}
                    </Typography>
                ))}
            </Stack>
        )}
    </Box>
);

export default function AdminDashboardAiInsightPanel({
                                                         overview,
                                                         insight,
                                                         loading,
                                                         error,
                                                         onRun,
                                                     }) {
    const attempts = overview?.totalAttempts ?? 0;
    const students = overview?.totalStudents ?? 0;

    return (
        <CardShell>
            <Box sx={{ px: 2.75, py: 2.25 }}>
                <Stack direction={{ xs: "column", md: "row" }} justifyContent="space-between" spacing={2} alignItems={{ md: "center" }}>
                    <Box sx={{ minWidth: 0 }}>
                        <Typography sx={{ fontWeight: 950, color: COLORS.textPrimary, fontSize: 16 }}>
                            AI phân tích tuần này
                        </Typography>
                        <Typography sx={{ mt: 0.4, color: COLORS.textSecondary, fontWeight: 700, fontSize: 13 }}>
                            Tóm tắt nhanh để admin hành động (không chạy tự động — bấm nút để phân tích)
                        </Typography>
                    </Box>

                    <Stack direction="row" spacing={1} alignItems="center">
                        <Chip
                            label={`Dựa trên ${fmtInt(attempts)} bài làm • ${fmtInt(students)} học viên`}
                            sx={{
                                borderRadius: "999px",
                                bgcolor: COLORS.bg,
                                border: `1px solid ${COLORS.border}`,
                                fontWeight: 900,
                                color: COLORS.textSecondary,
                            }}
                        />

                        <Button
                            onClick={onRun}
                            startIcon={loading ? <CircularProgress size={16} sx={{ color: COLORS.white }} /> : <AutoAwesomeRounded />}
                            disabled={loading}
                            variant="contained"
                            sx={{
                                borderRadius: "12px",
                                bgcolor: COLORS.accentOrange,
                                fontWeight: 900,
                                textTransform: "none",
                                boxShadow: "none",
                                "&:hover": { bgcolor: COLORS.accentOrangeHover, boxShadow: "none" },
                            }}
                        >
                            {loading ? "Đang phân tích..." : "Phân tích bằng AI"}
                        </Button>
                    </Stack>
                </Stack>
            </Box>

            <Divider sx={{ borderColor: COLORS.border }} />

            <Box sx={{ p: 2.5 }}>
                {error ? (
                    <Chip
                        icon={<RefreshRounded />}
                        label={error}
                        sx={{
                            mb: 2,
                            bgcolor: `${COLORS.danger}12`,
                            color: COLORS.danger,
                            fontWeight: 900,
                            border: `1px solid ${COLORS.border}`,
                            borderRadius: "999px",
                        }}
                    />
                ) : null}

                {!insight ? (
                    <Typography sx={{ color: COLORS.textSecondary, fontWeight: 800 }}>
                        Bấm “Phân tích bằng AI” để tạo báo cáo tuần này.
                    </Typography>
                ) : (
                    <Stack spacing={2}>
                        <Box>
                            <Typography sx={{ fontWeight: 950, color: COLORS.textPrimary, mb: 0.5 }}>
                                Tóm tắt
                            </Typography>
                            <Typography sx={{ color: COLORS.textSecondary, fontWeight: 700 }}>
                                {insight.summary || "—"}
                            </Typography>
                        </Box>

                        <Divider sx={{ borderColor: COLORS.border }} />

                        <Section title="Nhóm vấn đề chính" items={insight.keyProblems || []} />
                        <Divider sx={{ borderColor: COLORS.border }} />
                        <Section title="Mẫu hình at-risk" items={insight.atRiskPatterns || []} />
                        <Divider sx={{ borderColor: COLORS.border }} />
                        <Section title="Gợi ý hành động" items={insight.recommendedActions || []} />

                        <Typography sx={{ color: COLORS.textSecondary, fontWeight: 800, fontSize: 12 }}>
                            Độ tin cậy: {Math.round((insight.confidence ?? 0) * 100)}% • Tạo lúc: {insight.generatedAt || "-"}
                        </Typography>
                    </Stack>
                )}
            </Box>
        </CardShell>
    );
}
