// src/features/admin/components/dashboard/AdminDashboardFilterBar.jsx
import React, { useMemo, useRef, useState } from "react";
import {
    Box,
    Stack,
    Typography,
    Button,
    IconButton,
    Tooltip,
    Collapse,
    TextField,
    MenuItem,
} from "@mui/material";
import { FilterList, RestartAltRounded } from "@mui/icons-material";

import { DASHBOARD_COLORS as COLORS } from "./dashboard.helpers";

/**
 * Admin Dashboard Filter Bar
 * - Không search
 * - Nền trong suốt mờ để lộ background header
 * - Toggle ẩn/hiện filter
 * - Auto-apply khi đổi field
 *
 * filters:
 * {
 *   preset: "7d"|"30d"|"custom",
 *   classId: "",
 *   moduleId: "",
 *   fromDate: "YYYY-MM-DD",
 *   toDate: "YYYY-MM-DD"
 * }
 */
export default function AdminDashboardFilterBar({
                                                    classes = [],
                                                    modules = [],
                                                    filters,
                                                    loading = false,
                                                    onChange,   // (nextFilters) => void (setState)
                                                    onReset,    // () => void
                                                    onAutoApply // (nextFilters) => void (fetch)
                                                }) {
    const [open, setOpen] = useState(true);
    const timerRef = useRef(null);

    const presetOptions = useMemo(
        () => [
            { value: "7d", label: "7 ngày gần nhất" },
            { value: "30d", label: "30 ngày gần nhất" },
            { value: "custom", label: "Tuỳ chọn" },
        ],
        []
    );

    const classOptions = useMemo(() => {
        const base = [{ value: "", label: "Tất cả lớp" }];
        const mapped = classes.map((c) => ({ value: String(c.id), label: c.name }));
        return [...base, ...mapped];
    }, [classes]);

    const moduleOptions = useMemo(() => {
        const base = [{ value: "", label: "Tất cả module" }];
        const mapped = modules.map((m) => ({ value: String(m.id), label: m.name }));
        return [...base, ...mapped];
    }, [modules]);

    const applyNext = (next) => {
        // debounce nhẹ để tránh gọi dồn khi click nhanh
        if (timerRef.current) clearTimeout(timerRef.current);
        timerRef.current = setTimeout(() => onAutoApply?.(next), 120);
    };

    const patch = (p) => {
        const next = { ...filters, ...p };
        onChange?.(next);
        applyNext(next);
    };

    const onPresetChange = (preset) => {
        if (preset === "custom") {
            patch({ preset: "custom" });
            return;
        }

        // preset: set from/to date tự động
        const now = new Date();
        const to = new Date(now);
        const from = new Date(now);
        from.setDate(from.getDate() - (preset === "30d" ? 29 : 6));

        const toDate = to.toISOString().slice(0, 10);
        const fromDate = from.toISOString().slice(0, 10);

        patch({ preset, fromDate, toDate });
    };

    return (
        <Box
            sx={{
                borderRadius: "16px",
                bgcolor: "rgba(255,255,255,0.14)",
                border: "1px solid rgba(255,255,255,0.22)",
                backdropFilter: "blur(10px)",
                overflow: "hidden",
            }}
        >
            {/* Top row: title + actions */}
            <Box sx={{ px: 1.5, py: 1.25 }}>
                <Stack direction="row" alignItems="center" justifyContent="space-between" spacing={1.25}>
                    <Stack direction="row" spacing={1} alignItems="center" sx={{ minWidth: 0 }}>
                        <Box
                            sx={{
                                width: 34,
                                height: 34,
                                borderRadius: "12px",
                                display: "grid",
                                placeItems: "center",
                                bgcolor: "rgba(255,255,255,0.16)",
                                border: "1px solid rgba(255,255,255,0.18)",
                            }}
                        >
                            <FilterList sx={{ color: "#fff", fontSize: 18 }} />
                        </Box>

                        <Box sx={{ minWidth: 0 }}>
                            <Typography sx={{ color: "#fff", fontWeight: 950, fontSize: 14 }}>
                                Bộ lọc thống kê
                            </Typography>
                            <Typography sx={{ color: "rgba(255,255,255,0.9)", fontWeight: 700, fontSize: 12 }}>
                                Đổi filter sẽ tự cập nhật dashboard
                            </Typography>
                        </Box>
                    </Stack>

                    <Stack direction="row" spacing={1} alignItems="center">
                        <Button
                            onClick={() => setOpen((p) => !p)}
                            variant={open ? "contained" : "outlined"}
                            sx={{
                                borderRadius: "12px",
                                textTransform: "none",
                                fontWeight: 900,
                                color: "#fff",
                                bgcolor: open ? "rgba(255,255,255,0.16)" : "transparent",
                                border: "1px solid rgba(255,255,255,0.22)",
                                boxShadow: "none",
                                "&:hover": {
                                    bgcolor: "rgba(255,255,255,0.22)",
                                    boxShadow: "none",
                                },
                            }}
                        >
                            {open ? "Ẩn bộ lọc" : "Mở bộ lọc"}
                        </Button>

                        <Tooltip title="Đặt lại bộ lọc">
                            <IconButton
                                onClick={onReset}
                                sx={{
                                    width: 40,
                                    height: 40,
                                    borderRadius: "12px",
                                    color: "#fff",
                                    bgcolor: "rgba(255,255,255,0.16)",
                                    border: "1px solid rgba(255,255,255,0.22)",
                                    "&:hover": { bgcolor: "rgba(255,255,255,0.24)" },
                                }}
                            >
                                <RestartAltRounded />
                            </IconButton>
                        </Tooltip>
                    </Stack>
                </Stack>
            </Box>

            {/* Fields */}
            <Collapse in={open} timeout={180}>
                <Box sx={{ px: 1.5, pb: 1.5 }}>
                    <Box
                        sx={{
                            borderRadius: "14px",
                            bgcolor: "rgba(255,255,255,0.10)",
                            border: "1px solid rgba(255,255,255,0.18)",
                            p: 1.25,
                        }}
                    >
                        <Box
                            sx={{
                                display: "grid",
                                gridTemplateColumns: { xs: "1fr", md: "repeat(3, minmax(0, 1fr))" },
                                gap: 1.25,
                            }}
                        >
                            <TextField
                                select
                                fullWidth
                                size="small"
                                label="Khoảng thời gian"
                                value={filters.preset ?? "7d"}
                                onChange={(e) => onPresetChange(e.target.value)}
                                disabled={loading}
                                InputLabelProps={{ sx: { fontWeight: 900 } }}
                                sx={{
                                    "& .MuiInputBase-root": { bgcolor: "rgba(255,255,255,0.92)" },
                                    "& label": { color: COLORS.textPrimary },
                                }}
                            >
                                {presetOptions.map((p) => (
                                    <MenuItem key={p.value} value={p.value}>
                                        {p.label}
                                    </MenuItem>
                                ))}
                            </TextField>

                            <TextField
                                select
                                fullWidth
                                size="small"
                                label="Lớp"
                                value={filters.classId ?? ""}
                                onChange={(e) => patch({ classId: e.target.value })}
                                disabled={loading}
                                InputLabelProps={{ sx: { fontWeight: 900 } }}
                                sx={{
                                    "& .MuiInputBase-root": { bgcolor: "rgba(255,255,255,0.92)" },
                                    "& label": { color: COLORS.textPrimary },
                                }}
                            >
                                {classOptions.map((c) => (
                                    <MenuItem key={c.value} value={c.value}>
                                        {c.label}
                                    </MenuItem>
                                ))}
                            </TextField>

                            <TextField
                                select
                                fullWidth
                                size="small"
                                label="Module"
                                value={filters.moduleId ?? ""}
                                onChange={(e) => patch({ moduleId: e.target.value })}
                                disabled={loading}
                                InputLabelProps={{ sx: { fontWeight: 900 } }}
                                sx={{
                                    "& .MuiInputBase-root": { bgcolor: "rgba(255,255,255,0.92)" },
                                    "& label": { color: COLORS.textPrimary },
                                }}
                            >
                                {moduleOptions.map((m) => (
                                    <MenuItem key={m.value} value={m.value}>
                                        {m.label}
                                    </MenuItem>
                                ))}
                            </TextField>
                        </Box>

                        {filters.preset === "custom" ? (
                            <Box
                                sx={{
                                    mt: 1.25,
                                    display: "grid",
                                    gridTemplateColumns: { xs: "1fr", md: "repeat(2, minmax(0, 1fr))" },
                                    gap: 1.25,
                                }}
                            >
                                <TextField
                                    fullWidth
                                    size="small"
                                    label="Từ ngày"
                                    type="date"
                                    value={filters.fromDate ?? ""}
                                    onChange={(e) => patch({ fromDate: e.target.value })}
                                    disabled={loading}
                                    InputLabelProps={{ shrink: true, sx: { fontWeight: 900 } }}
                                    sx={{ "& .MuiInputBase-root": { bgcolor: "rgba(255,255,255,0.92)" } }}
                                />
                                <TextField
                                    fullWidth
                                    size="small"
                                    label="Đến ngày"
                                    type="date"
                                    value={filters.toDate ?? ""}
                                    onChange={(e) => patch({ toDate: e.target.value })}
                                    disabled={loading}
                                    InputLabelProps={{ shrink: true, sx: { fontWeight: 900 } }}
                                    sx={{ "& .MuiInputBase-root": { bgcolor: "rgba(255,255,255,0.92)" } }}
                                />
                            </Box>
                        ) : null}
                    </Box>
                </Box>
            </Collapse>
        </Box>
    );
}
